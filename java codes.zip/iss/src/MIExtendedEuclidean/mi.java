package MIExtendedEuclidean;

import java.util.*;
import EuclideanGCD.*;

public class mi 
{
   public static int modInverse(int a, int m)
    {
      
        for (int x = 1; x < m; x++)
            if (((a%m) * (x%m)) % m == 1) 
            {
            	//System.out.println(a+ " "+ x);
                return x;
            }
        return 1;
    }
 
    public static void main(String args[])
    {
    	Scanner sc =new Scanner(System.in);
    	System.out.print("Enter Number : ");
    	int a = sc.nextInt();
    	System.out.print("Enter Modular Value : ");
    	int m = sc.nextInt();
       
        System.out.println("Multiplicative Inverse Modulo of ("+a+" , "+m+") = "+ modInverse(a, m));
    }
	
}
