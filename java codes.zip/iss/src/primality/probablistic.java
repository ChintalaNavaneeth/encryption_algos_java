package primality;

import java.util.Scanner;

public class probablistic {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("--- Deterministic primality testing ---");
		System.out.print("Enter a number to check a prime or not : ");
		int n = sc.nextInt();
		System.out.print("Enter a base : ");
		int a = sc.nextInt();
		System.out.println(propri(n,a));

	}
	public static String propri(int n,int a) // n =number, a=base
	{
		int x[] = findmk(n);
		int m = x[1];
		int k = x[0];
		System.out.println("k value : " + k);
		System.out.println("m value : " +m);

		int t = ((int) Math.pow(a,m))%n;
		if(t == 1%n || t == -1%n)
		{
			return "Prime";
		}
		for(int i=1;i<=k;i++)
		{
			t = (int)(Math.pow(t, 2))%n;
			t = t-n;
			if(t == 1)
			{
				return "Composite";
			}
			if(t == -1)
			{
				return "Prime";
			}
		}
		return "composite";
	}
	
	// Finding m and k values
	public static int[] findmk(int x)
	{
		int k=0;
		int n = x-1;
		int values[] = new int[2]; 
		boolean e =true;
		while(e)
		{
			double m = (n/Math.pow(2, k));
			if(Math.floor(m) == m)
			{
				k++;
			}
			else
			{
				e = false;
			}
		}
		values[0] = k-1;
		values[1] = (int)(n/Math.pow(2, k-1));
		return values;

	}

}
