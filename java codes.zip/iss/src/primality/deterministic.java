package primality;
import java.util.*;

public class deterministic {
	public static void main(String args[])
	{
		Scanner sc = new Scanner (System.in);
		System.out.println("--- Deterministic primality testing ---");
		System.out.print("Enter a number to check a prime or not : ");
		int x = sc.nextInt();
		System.out.println(x+" is "+ detpri(x));
	}
	public static String detpri(int x)
	{
		int r =2;
		while(r<Math.sqrt(x))
		{
			if(x%r == 0)
			{
				return "composite";
			}
			r++;
		}
		return "Prime";
		
	}
}
