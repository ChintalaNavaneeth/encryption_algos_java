package EuclideanGCD;

import java.util.*;

public class gcd 
{
	public static void main(String Args[])
	{
		Scanner sc =new Scanner(System.in);
		System.out.println(" - Finding GCD using Euclidean Algorithm - ");
		System.out.print("Enter First Number : ");
		int x =sc.nextInt();
		System.out.print("Enter Second Number : ");
		int y=sc.nextInt();
		int p = gcd(x,y);
        System.out.println("GCD(" + x +  " , " + y+ ") = " + p);
	}
	public static int gcd(int x, int y)
	{
		int r;
	        if (x == 0)
	        {
	            return y;
	        }
	        else
	        {
		        r = y%x;
		        System.out.println(y +"\t"+ x + "\t= "+r);
		        return gcd(r, x);
	        }
	}
}
