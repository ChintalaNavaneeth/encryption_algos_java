package ciphers;
import java.util.*;
import java.math.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
 
public class hill
{
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
   public static String split(String x,int [][] keymat )
   {
       x = x.toLowerCase(); //lowering the letters of plain text

	   String charc ="z";
	   if(x.length()%2 == 1) //padding letters
	   {
		   	x=x+charc;
	   }
	  char z[] =  x.toCharArray();
	  String encryptedtext = "";
	   for(int i=0;i<x.length();i++) //splitting the plain text into 2 chars each
	   {
		   int o[] =  new int [2];
           int charPosition = ALPHABET.indexOf(x.charAt(i));
           int charPosition2 = ALPHABET.indexOf(x.charAt(i+1));
           i = i+1;
           o[0] = charPosition;
           o[1] = charPosition2;
          // System.out.print(o[0]+"\n"+o[1]);
           encryptedtext +=  matrixmul(o,keymat); // appling matrix multiplication to text chars integers and key matrix
	   }
	   return encryptedtext;
	  // System.out.println("Encrypted Text : "+encryptedtext);
  }
	public static String matrixmul(int text[],int keymat[][])
	{	
		StringBuilder sb = new StringBuilder();
		char ans [] = new char[text.length];
		for(int i=0;i<text.length;i++)
		{		int e = 0;

			int k=0;
			for(int j=0;j<keymat.length;j++)
			{
				e = text[k] * keymat[j][i] + e; 
				k++;
			}
			ans[i] = ALPHABET.charAt(e%26);
			sb.append(ALPHABET.charAt(e%26));
		}
		return sb.toString();
		//System.out.println(sb.toString());		
	}
    public static void decrypt(String line,String key)
    {
        double sq = Math.sqrt(key.length());
    	BigInteger keymats[][] = new BigInteger[(int) sq][(int) sq];

        int keymat[][] =new int[(int) sq][(int)sq]; 
        int m=0;
        for(int i=0;i<sq;i++)
        {
        	for(int j=0;j<sq;j++)
        	{
        		//System.out.println(ALPHABET.indexOf(key.charAt(m)));
        		keymat[i][j] = ALPHABET.indexOf(key.charAt(m));
        		m++;
        	}
        } 
        for(int i=0;i<sq;i++)
        {
        	for(int j=0;j<sq;j++)
        	{
        		keymats[i][j] = BigInteger.valueOf(keymat[i][j]);
        	}
        }  
        ModMatrix obj2= new ModMatrix(keymats);
        ModMatrix inverse2 = obj2.inverse(obj2);
        
        for (int i = 0; i < inverse2.getNrows(); i++) 
        {
            for (int j = 0; j < inverse2.getNcols(); j++)
            {
                         keymat[i][j] = inverse2.getData()[i][j].intValue();
            }
        }
       String lk = split(line,keymat);
        System.out.println("Encrypted Text : "+lk);

    }
    public static void encrypt(String line,String key)
    {
        double sq = Math.sqrt(key.length());
        int keymat[][] =new int[(int) sq][(int)sq]; 
        int m=0;
        for(int i=0;i<sq;i++)
        {
        	for(int j=0;j<sq;j++)
        	{
        		//System.out.println(ALPHABET.indexOf(key.charAt(m)));
        		keymat[i][j] = ALPHABET.indexOf(key.charAt(m));
        		m++;
        	}
        } 
       String lk =  split(line,keymat);
       System.out.println("Encrypted Text : "+lk);
    }
	public static void main(String args[]) throws IOException
	{
	   System.out.println("--- Hill Cipher ---");
	   Scanner in = new Scanner(System.in);
	    System.out.println("1: Encryption\n2: Decryption");
	    int choice = in.nextInt();
	    switch(choice)
	    {
	    case 1 : 
	        System.out.print("Enter the Text: ");
	        String line = in.next();
	        System.out.print("Enter the key: ");
	        String key = in.next();
	
	        double sq = Math.sqrt(key.length());
	        if (sq != (long) sq)
	        {
	            System.out.println("Invalid key length!!! Does not form a square matrix...");
	        	System.exit(0);
	        } 
	        encrypt(line,key);
	        break;
	    case 2 : 
	        System.out.print("Enter the Encrypted Cipher Text: ");
	        String enline = in.next();
	        System.out.print("Enter the key: ");
	        String enkey = in.next();
	
	        double sqr = Math.sqrt(enkey.length());
	        if (sqr != (long) sqr)
	        {
	            System.out.println("Invalid key length!!! Does not form a square matrix...");
	        	System.exit(0);
	        } 
	        decrypt(enline,enkey);
	    	break;
	    default :
	    	System.out.println("Enter Valid option ... ");
	    
	    }
	
	}
}