package ciphers;
import java.util.*;

public class playfaircipher 
{
	char[][] mat = new char[5][5];
	public static void  main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("-- Playfair Cipher--\nChoose Option\n1.Encryption\n2.Decryption");
		int x = sc .nextInt();

		switch(x)
		{
		case 1 :
			System.out.print("Enter Text : ");
			String s =sc.next();
			System.out.print("Enter Key : ");
			String k=sc.next();
			encrypt(s,k);
					break;
		case 2 :
			System.out.print("Enter Text : ");
			String st =sc.next();
			st.toLowerCase();
			System.out.print("Enter Key : ");
			String ke=sc.next();
			ke.toLowerCase();
			decrypt(st,ke);
					break;
		default : System.out.println("Enter Valid option");
		}
	}
	static void encrypt(String x, String k)
	{
		x = x.toLowerCase();
		k = k .toLowerCase();
		Playfair pfc1 = new Playfair(k, x);
		
		pfc1.cleanPlayFairKey();
		pfc1.generateCipherKey();
		
		String encText = pfc1.encryptMessage();
		System.out.println("Cipher Text is: " + encText);
	}
	static void decrypt(String x, String k)
	{
		x = x.toLowerCase();
		k = k .toLowerCase();
		Playfair pfc1 = new Playfair(k, x);
		pfc1.cleanPlayFairKey();
		pfc1.generateCipherKey();
		String deText = pfc1.decryptMessage();
		System.out.println("Plain Text is: " + deText);
	
	}
}
