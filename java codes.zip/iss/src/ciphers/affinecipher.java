package ciphers;

import java.util.Scanner;

public class affinecipher {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("--Affine Cipher--\n1.Encryption\n2.Decryption\n3.Decryption Brute Force");
		int x = sc.nextInt();
		switch(x)
			{
			case 1:
				System.out.print("Enter Text : ");
				String es = sc.next();
				System.out.print("Enter Key 1: ");
				int k1 =sc.nextInt();
				System.out.print("Enter Key 2: ");
				int k2 =sc.nextInt();
				encrypt(es,k1,k2);
				break;
			
			case 2 :
				System.out.print("Enter Text : ");
				String ds = sc.next();
				System.out.print("Enter Key1 : ");
				int key =sc.nextInt();
				System.out.print("Enter Key2 : ");
				int keys =sc.nextInt();
				decrypt(ds,key,keys);
				break;
				
			case 3:
				System.out.print("Enter Text : ");
				String dbs = sc.next();
				dbf(dbs);
				break;
			}
		
	}
	static void encrypt(String s , int k, int ke)
	{
		String x = multiplicativesubstitutioncipher.encrypt(s, k);
		//System.out.println(x);
		String y = caesarcipher.encrypt(x, ke);
		System.out.println(y);		
	}
	static void decrypt(String s, int k,int ke)
	{
		String u = caesarcipher.decrypt(s, ke);
		//System.out.println(u);
		String v = multiplicativesubstitutioncipher.decrypt(u, k);
		System.out.println(v);
	}
	static void dbf(String s)
	{
		for(int i=1;i<=26;i++)
		{
			for(int j = 1;j<=26;j=j+2)
			{
				System.out.print("For key ( "+j+" , "+i+" ) = ");
				decrypt(s,j,i);
			}
		}
		
	}

}
