package ciphers;
import MIExtendedEuclidean.*;
import java.util.Scanner;

public class multiplicativesubstitutioncipher 
{
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("--Multiplicative substitution Cipher--\n1.Encryption\n2.Decryption\n3.Decryption Brute Force");
		int x = sc.nextInt();
		switch(x)
			{
			case 1:
				System.out.print("Enter Text : ");
				String es = sc.next();
				System.out.print("Enter Key : ");
				int k =sc.nextInt();
				String j = encrypt(es,k);
				System.out.println(j);
				break;
			
			case 2 :
				System.out.print("Enter Text : ");
				String ds = sc.next();
				System.out.print("Enter Key : ");
				int key =sc.nextInt();
				String t = decrypt(ds,key);
				System.out.println(t);
				break;
				
			case 3:
				System.out.print("Enter Text : ");
				String dbs = sc.next();
				dbf(dbs);
				break;
			}
	}		
    public static String encrypt(String plainText, int shiftKey)
    {
        plainText = plainText.toLowerCase();
        String cipherText = "";
        for (int i = 0; i < plainText.length(); i++)
        {
            int charPosition = ALPHABET.indexOf(plainText.charAt(i));
            int keyVal = (shiftKey * charPosition) % 26;
            char replaceVal = ALPHABET.charAt(keyVal);
            cipherText += replaceVal;
        }
        return cipherText;
    }
 
    public static String decrypt(String cipherText, int shiftKey)
    {
    	mi q = new mi();
    	int keys = q.modInverse(shiftKey, 26);
        cipherText = cipherText.toLowerCase();
        String plainText = "";
        for (int i = 0; i < cipherText.length(); i++)
        {
            int charPosition = ALPHABET.indexOf(cipherText.charAt(i));
            int keyVal = (charPosition * keys) % 26;
            if (keyVal < 0)
            {
                keyVal = ALPHABET.length() + keyVal;
            }
            char replaceVal = ALPHABET.charAt(keyVal);
            plainText += replaceVal;
        }
        return plainText;
    }
	static void dbf(String s)
	{
		
		for(int i=1;i<=26;i=i+2)
		{
			String n = decrypt(s,i);
			System.out.println("key "+i+" = "+ n);
		}
	}
}

