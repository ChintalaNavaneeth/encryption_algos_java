package ciphers;

import java.util.Scanner;

public class otp {
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
	public static void main(String args[])
	{
		int x = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("--One Time Pad Cipher--\n1.Encryption\n2.Decryption");
		x = sc.nextInt();
		switch(x)
			{
			case 1:
				System.out.print("Enter Text : ");
				String es = sc.next();
				String h = randomkey(es.length());
				String q = encrypt(es,h);
				System.out.println("Cipher Text : "+q);
				break;
			
			case 2 :
				System.out.print("Enter Cipher Text : ");
				String ds = sc.next();
				System.out.print("Enter Key Text : ");
				String key =sc.next();
				String h1 = decrypt(ds,key);
				System.out.println("Plain Text : "+h1);
				break;
		}
		
	}		
    public static String encrypt(String plainText, String key)
    {
        plainText = plainText.toLowerCase();
        key = key.toLowerCase();
        String cipherText = "";
        for (int i = 0; i < plainText.length(); i++)
        {
        	int shiftKey = ALPHABET.indexOf(key.charAt(i));
            int charPosition = ALPHABET.indexOf(plainText.charAt(i));
            int keyVal = (shiftKey + charPosition) % 26;
            char replaceVal = ALPHABET.charAt(keyVal);
            cipherText += replaceVal;
        }
        System.out.println("Random Key String applied : "+key);
        return cipherText;
    }
 
   public static String decrypt(String cipherText, String key)
    {
        cipherText = cipherText.toLowerCase();
        key = key.toLowerCase();
        String plainText = "";
        for (int i = 0; i < cipherText.length(); i++)
        {
            int charPosition = ALPHABET.indexOf(cipherText.charAt(i));
            int keypos = ALPHABET.indexOf(key.charAt(i));
            int keyVal = (charPosition - keypos) % 26;
            if (keyVal < 0)
            {
                keyVal = ALPHABET.length() + keyVal;
            }
            char replaceVal = ALPHABET.charAt(keyVal);
            plainText += replaceVal;
        }
        return plainText;
    }
	public static String randomkey(int x)
	{
		StringBuilder s =new StringBuilder(x);
		for(int i=1;i<=x;i++)
		{
			int index = (int)(ALPHABET.length()*Math.random());
			s.append(ALPHABET.charAt(index));
		}
		return s.toString();
	}
}
