package ciphers;
import java.util.*;

public class caesarcipher 
{
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("--Caesar Cipher--\n1.Encryption\n2.Decryption\n3.Decryption Brute Force");
		int x = sc.nextInt();
		switch(x)
			{
			case 1:
				System.out.print("Enter Text : ");
				String es = sc.next();
		    	//String ess = es.replaceAll("\\s","");
				System.out.print("Enter Key : ");
				int k =sc.nextInt();
				String q = encrypt(es,k);
				System.out.println("Encrypted Text : " +q);
				break;
			
			case 2 :
				System.out.print("Enter Text : ");
				String ds = sc.next();
				System.out.print("Enter Key : ");
				int key =sc.nextInt();
				String h = decrypt(ds,key);
				System.out.println(h);
				break;
				
			case 3:
				System.out.print("Enter Text : ");
				String dbs = sc.next();
				dbf(dbs);
				break;
			}
	}		
    public static String encrypt(String plainText, int shiftKey)
    {
        plainText = plainText.toLowerCase();
        String cipherText = "";
        for (int i = 0; i < plainText.length(); i++)
        {
        	
            int charPosition = ALPHABET.indexOf(plainText.charAt(i));
            int keyVal = (shiftKey + charPosition) % 26;
            char replaceVal = ALPHABET.charAt(keyVal);
            cipherText += replaceVal;
        }
        return cipherText;
    }
 
    public static String decrypt(String cipherText, int shiftKey)
    {
        cipherText = cipherText.toLowerCase();
        String plainText = "";
        for (int i = 0; i < cipherText.length(); i++)
        {
            int charPosition = ALPHABET.indexOf(cipherText.charAt(i));
            int keyVal = (charPosition - shiftKey) % 26;
            if (keyVal < 0)
            {
                keyVal = ALPHABET.length() + keyVal;
            }
            char replaceVal = ALPHABET.charAt(keyVal);
            plainText += replaceVal;
        }
        return plainText;
    }
	static void dbf(String s)
	{
		
		for(int i=1;i<=26;i++)
		{
			String n = decrypt(s,i);
			System.out.println("key "+i+" = "+ n);
		}
	}
}
