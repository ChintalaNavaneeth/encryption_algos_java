package ciphers;
import java.util.*;

public class vigenerecipher {

	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";

	public static void main(String[] args)
	{
		Scanner sc = new Scanner (System.in);
		System.out.println("--Vigenere Cipher--\n1.Encryption\n2.Decryption");
		int x =sc.nextInt();
		switch(x)
		{
		case 1 : 
			System.out.print("Enter Text : ");
			String et = sc.next();
			System.out.print("Enter Key Word : ");
			String key =sc.next();
			String j = encrypt(et,key);
			System.out.println(j);
			break;
		case 2 : 
			System.out.print("Enter Text : ");
			String dt = sc.next();
			System.out.print("Enter Key Word : ");
			String k =sc.next();
			String h = decrypt(dt,k);
			System.out.println(h);
			break;
		
			default :
				System.out.println("Enter valid option");
		}

	}
	public static String encrypt(String plaintext, String key)
	{
		String ciphertext ="";
 		String p = keystream(plaintext,key);
		for(int i=0; i<plaintext.length(); i++)
		{
			int charposition = ALPHABET.indexOf(plaintext.charAt(i));
			int keyposition = ALPHABET.indexOf(p.charAt(i));

			int keyval = (charposition + keyposition )%26;

			char replaceval = ALPHABET.charAt(keyval);
			ciphertext += replaceval; 
		}
		return ciphertext;
	}
	public static String decrypt(String cipher, String key)
	{
		String ciphertext ="";
 		String p = keystream(cipher,key);
		for(int i=0; i<cipher.length(); i++)
		{
			int charposition = ALPHABET.indexOf(cipher.charAt(i));
			int keyposition = ALPHABET.indexOf(p.charAt(i));

			int keyval = (charposition - keyposition )%26;
			if(keyval < 0)
			{
				keyval = keyval + 26;
			}
			
			char replaceval = ALPHABET.charAt(keyval);
			ciphertext += replaceval; 
		}
		return ciphertext;
		
	}
	public static String keystream(String x, String k)
	{
	    int y = x.length();
	    
	    for (int i = 0; ; i++)
	    {
	        if (y == i)
	            i = 0;
	        if (k.length() == x.length())
	            break;
	        k+=(k.charAt(i));
	    }
	    return k;		
	    
	}
	
}

