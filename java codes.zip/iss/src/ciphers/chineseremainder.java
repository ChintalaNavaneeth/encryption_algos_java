package ciphers;

import MIExtendedEuclidean.mi;
import java.util.*;

import EuclideanGCD.gcd;

public class chineseremainder {
	public static void main(String args[])
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Equations Format : x  ≅  y(mod n)");
		System.out.print("Enter number of equations do you have : ");
		int eqnos = sc.nextInt();
		
		
		System.out.println("Enter 'n' values : ");
		int nvals[] = new int[eqnos];
		for(int i =0 ;i<eqnos ; i++)
		{
			nvals[i] = sc.nextInt();
		}

		
		System.out.println("Enter 'y' values : ");
		int yvals[] = new int[eqnos];
		for(int i =0 ;i<eqnos ; i++)
		{
			yvals[i] = sc.nextInt();
		}
		
		crt(nvals,yvals,eqnos);
	}
	
	public static void crt(int nvals[], int yvals[],int eqnos)
	{
		int x = 0;
		int M=1;
		int m [] = new int [eqnos];
		int minv[] = new int[eqnos];

		for(int i=0;i<eqnos;i++)
		{ 
			M = M * nvals[i];
		}
		
		for(int i =0;i<eqnos;i++)
		{
			m[i] = M/nvals[i];
		}
		
		for(int i =0;i<eqnos;i++)
		{
			minv[i] = MIExtendedEuclidean.mi.modInverse(m[i], nvals[i]);
			x = x + (minv[i] * m[i] * yvals[i]);
		}

		x= x%M;
		System.out.println("x ≅ "+x);		
	}
	
}
