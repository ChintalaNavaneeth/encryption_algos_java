package ciphers;
import java.util.*;
public class autokeycipher 
{
	public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("--Autokey Cipher--\n1.Encryption\n2.Decryption\n3.Decryption Brute Force");
		int x = sc.nextInt();
		switch(x)
			{
			case 1:
				System.out.print("Enter Plain Text : ");
				String es = sc.next();
				System.out.print("Enter Key : ");
				int k1 =sc.nextInt();
				String u = encrypt(es,k1);
				System.out.println(u);
				break;
			
			case 2 :
				System.out.print("Enter Cipher Text : ");
				String ds = sc.next();
				System.out.print("Enter Key : ");
				int key =sc.nextInt();
				String y = decrypt(ds,key);
				System.out.println(y);
				break;
				
			case 3:
				System.out.print("Enter Cipher Text : ");
				String dbs = sc.next();
				dbf(dbs);
				break;
			}
	}

	public static String encrypt(String plaintext, int k)
	{
		plaintext =plaintext.toLowerCase();
		String ciphertext="";
		int prevcharposition = 0;
		for(int i=0; i<plaintext.length(); i++)
		{
			int charposition = ALPHABET.indexOf(plaintext.charAt(i));
			int keyval = (charposition + prevcharposition + k)%26;

			char replaceval = ALPHABET.charAt(keyval);
			ciphertext += replaceval; 
			k=0;
			prevcharposition = charposition;
		}
		return ciphertext;
		
	}
	public static String decrypt(String ciphertext, int k)
	{
        ciphertext = ciphertext.toLowerCase();
        String plainText = "";
        for (int i = 0; i < ciphertext.length(); i++)
        {
            int charPosition = ALPHABET.indexOf(ciphertext.charAt(i));
            int keyVal = (charPosition - k) % 26;
            if (keyVal < 0)
            {
                keyVal = ALPHABET.length() + keyVal;
            }
            k=keyVal;
            char replaceVal = ALPHABET.charAt(keyVal);
            plainText += replaceVal;
        }
        return plainText;
		
	}	
	public static void dbf(String s)
	{
		for(int i=1;i<=26;i++)
			System.out.println("key "+i+" = "+decrypt(s,i));
	}
	
}