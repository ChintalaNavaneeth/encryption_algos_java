package RSA;

import java.util.*;
import java.io.DataInputStream;
import java.io.IOException;
import java.math.BigInteger;
public class rsa
{
    private BigInteger p,q,N,phi,e,d;
    private int bitlength = 1024;
    private Random r;
    public rsa()
    {
        r = new Random();
        p = BigInteger.probablePrime(bitlength, r);
        q = BigInteger.probablePrime(bitlength, r);
        N = p.multiply(q);
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        e = BigInteger.probablePrime(bitlength / 2, r);
        while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0)
        {
            e.add(BigInteger.ONE);
        }
        d = e.modInverse(phi);
    }
    public rsa(BigInteger e, BigInteger d, BigInteger N)
    {
        this.e = e;
        this.d = d;
        this.N = N;
    }
    public static void main(String[] args) throws IOException
    {
    	System.out.println("-- RSA -- ");
    	Scanner sc= new Scanner(System.in);
        rsa rsa = new rsa();
        System.out.println("1. Encryption\n2. Decryption");
        int option =sc.nextInt();
        switch(option)
        {
        case 1 : 
            System.out.print("Enter String to Encrypt : ");
            String teststring=sc.next();
            System.out.println("-----------------");
            System.out.println("Encrypting String: " + teststring);
            System.out.println("String in Bytes: "+ bytesToString(teststring.getBytes()));
            // encrypt
            byte[] encrypted = rsa.encrypt(teststring.getBytes());
            String encrypt = Base64.getEncoder().encodeToString(encrypted);
            System.out.println("Encrypted Message : "+encrypt);
            break;
        
        case 2 : 
            // decrypt
        	System.out.println("Enter encrypted message : ");
        	String encmsg =sc.next();
        	byte[] dp = Base64.getDecoder().decode(encmsg);
        	byte[] decrypted = rsa.decrypt(dp);
            System.out.println("-----------------");
            System.out.println("Decrypting Bytes: " + bytesToString(decrypted));
            System.out.println("Decrypted String: " + new String(decrypted));
            System.out.println("-----------------");
            break;
        }
    }
    private static String bytesToString(byte[] encrypted)
    {
        String test = "";
        for (byte b : encrypted)
        {
            test += Byte.toString(b);
        }
        return test;
    }
    // Encrypt message
    public byte[] encrypt(byte[] message)
    {
    	System.out.println("\npublic keys : \ne : "+e+"\nn : "+N);
    	System.out.println("Private key d : "+d);
        return (new BigInteger(message)).modPow(e, N).toByteArray();
    }
    // Decrypt message
    public byte[] decrypt(byte[] message)
    {
    	Scanner in = new Scanner(System.in);
    	System.out.println("Enter private key d : ");
    	d = in.nextBigInteger();
    	System.out.println("Enter n value : ");
    	N = in.nextBigInteger();
        return (new BigInteger(message)).modPow(d, N).toByteArray();
    }
}

