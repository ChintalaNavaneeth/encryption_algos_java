package elgamal;

import java.util.*;
import java.io.DataInputStream;
import java.io.IOException;
import java.math.*;
public class ElGamal
{
   // private static final Scanner  = null;
	private BigInteger p,r,e1,d,e2,maxlimit,minlimit;
	byte[] C2;
	byte[] C1;
	
    private int bitlength = 1024;
    private Random res;
    public ElGamal()
    {

        res = new Random();

        p =(BigInteger.probablePrime(bitlength, res));
        int len = p.bitLength();
        r = new BigInteger(len,res);
        e1 = BigInteger.probablePrime(bitlength / 2, res);
        e2 = BigInteger.probablePrime(bitlength / 2, res);


        d = e1.modInverse(p);
        e2 = e1.modPow(d,p);
        }
    public ElGamal(BigInteger e1,BigInteger e2, BigInteger d)
    {
        this.e1 = e1;
        this.e2 = e2;
        this.d = d;
    }
    public static void main(String[] args)// throws IOException
    {
    	System.out.println("-- elgamal Encryption And Decryption -- ");
    	Scanner sc= new Scanner(System.in);
        ElGamal elgamal = new ElGamal();
        System.out.println("1. Encryption\n2. Decryption");
        int option =sc.nextInt();
        switch(option)
        {
        case 1 : 
            System.out.print("Enter String to Encrypt : ");
            String teststring=sc.next();
            System.out.println("-----------------");
            System.out.println("Encrypting String: " + teststring);
            System.out.println("String in Bytes: "+ bytesToString(teststring.getBytes()));
            // encrypt
            byte[] encrypted = elgamal.encrypt(teststring.getBytes());
            //String encrypt = Base64.getEncoder().encodeToString(encrypted);
            //System.out.println("Encrypted Message : "+encrypt);
            break;
        
        case 2 : 
            // decrypt
        	System.out.println("Enter encrypted message C1: ");
        	String encmsg =sc.next();
        	byte[] dp = Base64.getDecoder().decode(encmsg);
        	byte[] decrypted = elgamal.decrypt(dp);
            System.out.println("-----------------");
            System.out.println("Decrypting Bytes: " + bytesToString(decrypted));
            System.out.println("Decrypted String: " + new String(decrypted));
            System.out.println("-----------------");
            break;
        }
    }
    private static String bytesToString(byte[] encrypted)
    {
        String test = "";
        for (byte b : encrypted)
        {
            test += Byte.toString(b);
        }
        return test;
    }
    // Encrypt message
    public byte[] encrypt(byte[] message)
    {
    	System.out.println("e1 : "+e1+"\ne2 : "+e2);
    	
    	C1 = e1.modPow(r, p).toByteArray();
    	C2 = new BigInteger(message).multiply(e2.modPow(r, p)).toByteArray();
    	System.out.println("Private key d : "+d);

    	System.out.println("Encrypted Texts C1, C2 : ");
        String encryptC1 = Base64.getEncoder().encodeToString(C1);
    	System.out.println("C1 : "+encryptC1);
        String encryptC2 = Base64.getEncoder().encodeToString(C2);
    	System.out.println("C2 : "+encryptC2);
        return C2;
    }
    // Decrypt message
    public byte[] decrypt(byte[] message)
    {
    	Scanner sc = new Scanner(System.in);
      	System.out.println("Enter encrypted message C2: ");
    	String encmsg =sc.next();
    	C2 = Base64.getDecoder().decode(encmsg);
    	
    	System.out.println("Enter public key e1 : ");
    	e1 = sc.nextBigInteger();
    	System.out.println("Enter public key e2 : ");
    	e2 =sc.nextBigInteger();
    	System.out.println("Enter Private key d : ");
    	d = sc.nextBigInteger();

    	
    	return new BigInteger(message).multiply(e2.modPow(r, p)).multiply(e1.modPow(r, p).modPow(d, p).modPow(p.subtract(BigInteger.TWO), p)).toByteArray();
    	//byte[] P = e1.modPow(r, p).modPow(d, p).modPow(p.subtract(BigInteger.TWO), p).toByteArray();
    	//return (new BigInteger(message)).modPow(d, N).toByteArray()
    }
}


    