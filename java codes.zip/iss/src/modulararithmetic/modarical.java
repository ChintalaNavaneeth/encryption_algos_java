package modulararithmetic;
import java.util.*;

public class modarical 
{
	static int add()
	{	Scanner sc= new Scanner(System.in);
		char p = '\0';
		int s= 0;
		{ 
			int x= sc.nextInt();
			s = s+x;
			p =sc.next().charAt(0);
		}
		while( p == '+');
		return s;	
	}
	
	static void addition()
	{		
		Scanner x = new Scanner(System.in);

		System.out.print("Enter Modular value : ");
		int m =x.nextInt();
		System.out.println("Enter numbers and press '+' to add the sum and '=' to find Modular Arithmetic Addition");
		int p = add();
		System.out.println("Total Sum = "+p);

		System.out.println("Modular addition of sum ("+p+" % "+m+" ) = "+ p%m+"\n\n");
	}	
	static int subs(int m)
	{
		Scanner sc= new Scanner(System.in);
			char p = '\0';
			int s= 0;
			int y = sc.nextInt();
			char z =sc.next().charAt(0);
			
			do
			{ 
				int x = sc.nextInt();
				s = s - (x%m);
				p =sc.next().charAt(0);
			}
			while( p == '-');
			return (s+y)%m;		
	}
	static void subtraction()
	{
		Scanner x = new Scanner(System.in);
		System.out.print("Enter Modular value : ");
		int m =x.nextInt();
		System.out.println("Enter numbers and press '-' to add the sum and '=' to find Modular Arithmetic Addition");
		int sum = subs(m);
		//System.out.println("Total Sum = "+sum);
		if( sum < 0)
		{
		 sum = sum+m;
		}

		System.out.println("Modular subtraction is "+ sum%m +"\n\n");
	}
	static int mul(int m)
	{	Scanner sc= new Scanner(System.in);
		char p = '\0';
		int s=1;
		do
		{ 
			int x= sc.nextInt();
			int t =x%m;
			s = s*t;
			p =sc.next().charAt(0);
		}
		while( p == '*' || p=='x' || p=='X');
		return s;	
	}
	static void multiplication()
	{
		Scanner x = new Scanner(System.in);
		System.out.print("Enter Modular value : ");
		int m =x.nextInt();
		System.out.println("Enter numbers and press '*' to multiply the product and '=' to find Modular Arithmetic Addition");
		int sum = mul(m);
		System.out.println("Total Product = "+sum);
		int q = sum%m;
		if(q < 0)
		{
		 q = q+m;
		}

		System.out.println("Modular multiplication of input is  "+ q +"\n\n");
	}

	
	static void inveradd()
	{
		Scanner sc =new Scanner(System.in);
		System.out.print("Enter a number to find additive inverse : ");
		int x = sc.nextInt();
		System.out.println("Additive Inverse of "+x+" = "+ (-x));
	}
	static void invermul()
	{
		Scanner s =new Scanner(System.in);
		System.out.print("Enter Modulo value : ");
		int p =s.nextInt();
		System.out.print("Enter the number to find multiplicative inverse : ");
		int o = s.nextInt();
		for(int x=1; x<p;x++)
		{
			if(((o%p)*(x%p))%p == 1)
			{
				System.out.println("Multiplicative Inverse of "+ o+" is "+x+"\n\n");
			}
		}
	}
	public static void main(String args[])
	{		
		int x = '\0';
		Scanner sc= new Scanner(System.in);
		do 
		{
		System.out.println("Choose Option : \n 1. Modular Arithmetic Addition\n 2. Modular Arithmetic Subtraction "
							+ "\n 3. Modular Arithmetic Multiplication"
							+ "\n 4. Additive inverse of a number \n 5. Multiplicative inverse of a number"
							+ "\n 6. Exit");
		x = sc.nextInt();
			switch(x)
				{
				case 1 :
					addition();
					break;
				
				case 2:
					subtraction();
					break;
				
				case 3:
					multiplication();
					break;
					
				case 4 :
					inveradd();
					break;
					
				case 5 :
					invermul();
					break;
					
				case 6 :
					System.out.println("-- Thank you --");
					System.exit(0);
					break;
				
				default :
					System.out.println("Enter valid option ...");
					}
			}while(x!=7);
	}
}
